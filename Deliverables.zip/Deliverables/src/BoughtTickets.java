import javax.swing.JPanel;

public class BoughtTickets extends JPanel {

	/**
	 * Create the panel.
	 */
	public BoughtTickets() {

	}

}
