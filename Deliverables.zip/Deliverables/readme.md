Install mysql
start mysql server with mysqld
run mysql -u < CreateTables.sql
run mysql -u < SimulatedData.sql
compile java any way you like
run Sqlconnecttest

test out and enjoy
test users include:

("Andrew", "Sheffield", "andrewsheffield@cs157a.com"),
("Peter", "Pham", "peterpham@cs157a.com"),
("Bowen", "Chan", "bowenchan@cs157a.com"),
("Suneuy", "Kim", "suneuy.kim@sjsu.edu")

ALL TEST user passwords are "password"